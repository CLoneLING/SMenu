# SMemu
# Introduce
SMemu is a Software composed of Windows Batch Scripts and VBScript.
# Indicate
In the main interface of this product, you can click on the "Code" section to download a version of SMemu software. The downloaded file type is ZIP archive. You need to decompress it and find "SMemu.exe" in it after decompression.Find it and double-click it to run.
